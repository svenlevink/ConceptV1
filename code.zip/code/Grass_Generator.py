import random
import csv

def random_pos(field, numbers):
    x = random.randint(0, 99)
    y = random.randint(0, 99)
    while field[x][y] != -1 or field[x][y] in numbers:
        x = random.randint(0, 99)
        y = random.randint(0, 99)
    return x, y

with open("No_go_zone.csv", "r") as f:
    reader = csv.reader(f)
    field = [[int(cell) for cell in row] for row in reader]

    numbers = [8, 9, 10]
    occurrences = 200

    for number in numbers:
        for i in range(occurrences):
            x, y = random_pos(field, numbers)
            if field[x][y] == -1:
                field[x][y] = number

    for x in range(100):
        for y in range(100):
            if field[x][y] == 666 or field[x][y] == 395:
                field[x][y] = -1

with open(r"C:\Users\Sven.Levink\OneDrive - Calco\Documenten\Concept V1\map\map_Grass.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(field)
