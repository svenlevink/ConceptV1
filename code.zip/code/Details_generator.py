import random

grid = [[-1 for i in range(100)] for j in range(100)]
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 32, 33, 34, 35, 36, 37, 38, 39, 49, 51, 53, 54, 55]

# fill 10 instances of each number randomly
for number in numbers:
    for i in range(3):
        row = random.randint(0, 99)
        col = random.randint(0, 99)
        while grid[row][col] != -1:
            row = random.randint(0, 99)
            col = random.randint(0, 99)
        grid[row][col] = number

# export the grid to a csv file
with open('map_Details.csv', 'w') as f:
    for row in grid:
        f.write(','.join(str(x) for x in row) + '\n')
