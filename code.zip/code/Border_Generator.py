import random

field = []
for i in range(100):
    row = []
    for j in range(100):
        if i == 0 or i == 99 or j == 0 or j == 99:
            row.append(395)
        else:
            row.append(-1)
    field.append(row)

for i in range(10):
    field[random.randint(1,98)][random.randint(1,98)] = 395

field[random.randint(1,98)][random.randint(1,98)] = -1

with open("map_FloorBlocks.csv", "w") as file:
    for row in field:
        file.write(",".join([str(number) for number in row]))
        file.write("\n")
